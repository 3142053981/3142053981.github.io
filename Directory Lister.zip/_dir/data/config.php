<?php
//000000000000
 exit();?>
a:14:{s:14:"admin_username";s:5:"admin";s:14:"admin_password";s:32:"e10adc3949ba59abbe56e057f20f883e";s:5:"title";s:12:"目录列表";s:8:"keywords";s:54:"目录列表,Directory Lister目录列表,目录索引";s:11:"description";s:18:"目录列表程序";s:8:"announce";s:0:"";s:6:"footer";s:0:"";s:11:"name_encode";s:4:"utf8";s:9:"file_hash";s:1:"1";s:13:"cache_indexes";s:1:"0";s:10:"footer_bar";s:1:"1";s:9:"readme_md";s:1:"1";s:4:"auth";s:1:"0";s:3:"nav";s:42:"说明*http://ddvnm.ct8.pl/?thread-31.htm|";}